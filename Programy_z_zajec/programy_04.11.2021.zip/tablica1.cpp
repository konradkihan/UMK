#include<iostream>
using namespace std;

int main()
{
    const int N = 1000;
    int A[N];

    for(int i = 0; i < N; i++)
        A[i] = 0;

    for(int i = 0; i < N; i++)
        cout<<A[i]<<" ";
}
