#include<iostream>
using namespace std;

int main()
{
    const int MAX = 100;
    int A[MAX];

    int n;
    cout << "Podaj rozmiar tablicy (n <= 100): ";
    cin >> n;

    for(int i = 0; i < n; i++)
        A[i] = 2 * i;

    for(int i = 0; i < n; i++)
        cout<<A[i]<<" ";
}
