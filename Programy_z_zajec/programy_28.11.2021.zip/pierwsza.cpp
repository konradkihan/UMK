#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    int n;
    cout<<"Podaj liczbe naturalna: ";
    cin >> n;
    bool czy_pierwsza = true;

   /* for(int i=2; i<=sqrt(n); i++)
    {
        //cout<<i<<endl;
        if (n % i == 0)
        {
            czy_pierwsza = false;
            //break;
            i = n;
        }

    } */

    int i = 2;
    while(i <= sqrt(n) && czy_pierwsza)
    {
        if(n % i == 0) czy_pierwsza = false;
        i++;
    }


    if(czy_pierwsza==true)
        cout<<"To jest liczba pierwsza";
    else
        cout<<"To nie jest liczba pierwsza";


}
