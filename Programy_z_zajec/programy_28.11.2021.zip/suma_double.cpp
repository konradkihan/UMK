#include<iostream>
using namespace std;

int main()
{
    const int N = 1000000000;

    float S = 0.0;

    for(int i=1; i <= N; i++)
        S = S + 0.1;

    cout<<S;
}
