#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    int n, i = 0;
    long long bin_n = 0;
    int podstawa = 2;
    cout<<"Podaj liczbe w systemie dziesietnym: ";
    cin >> n;

    while(n != 0)
    {
        bin_n = bin_n + (n % podstawa) * pow(10,i);
        n = n / podstawa;
        i++;
    }

    cout << bin_n;
}
