#include<iostream>

using namespace std;

int main()
{
    int n, suma_dzielnikow = 0;
    cout<<"Podaj liczbe naturalna: ";
    cin >> n;

    for(int i=1; i<=n/2; i++)
        if(n % i == 0) suma_dzielnikow += i;

    if(suma_dzielnikow == n)
        cout<<"Liczba jest doskonala";
    else
        cout<<"Liczba nie jest doskonala";
}
