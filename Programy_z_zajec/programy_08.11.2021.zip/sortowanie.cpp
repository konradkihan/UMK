#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

const int N = 1000000;
    double tab[N];

int main()
{


    srand(time(NULL));
    for(int i = 0; i < N; i++)
        tab[i] = 1.0 * rand() / RAND_MAX;
    cout << "Tablica nieposortowana"<<endl;
   /* for(int i = 0; i < N; i++)
        cout<<tab[i]<< " "; */

    for(int i = 0; i < N-1; i++)
    {
        double minimum;
        int min_index = i;
        minimum = tab[i];
        for(int j = i + 1; j < N; j++)
        {
            if(tab[j] < minimum)
            {
                minimum = tab[j];
                min_index = j;
            }
        }
        //swap(tab[i],tab[min_index]);
        double tmp;
        tmp = tab[i];
        tab[i] = tab[min_index];
        tab[min_index] = tmp;
    }
    cout << endl << "Tablica posortowana"<<endl;
  /*  for(int i = 0; i < N; i++)
        cout<<tab[i]<< " "; */
}
