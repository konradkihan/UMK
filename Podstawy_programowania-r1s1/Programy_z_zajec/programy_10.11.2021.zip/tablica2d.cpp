#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

int main()
{
    const int N = 4;
    int A[N][N];
    srand(time(NULL));

    for(int i = 0; i < N; i++)
        for(int j = 0; j < N; j++)
            A[i][j] = rand() % 10;

    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
            cout<<A[i][j]<<" ";
        cout<<endl;
    }
    int suma = 0;
    for(int i = 0; i < N; i++)
        for(int j = 0; j < N; j++)
            if (i<j) suma += A[i][j];
    cout<<endl<<suma;

    suma = 0;
    for(int i = 0; i < N; i++)
        for(int j = i + 1; j < N; j++)
            suma += A[i][j];
    cout<<endl<<suma;
}
