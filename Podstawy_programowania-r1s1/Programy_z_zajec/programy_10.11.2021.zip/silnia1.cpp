#include<iostream>
using namespace std;

long long silnia(int a);
long long newton(int n, int k);

int main()
{
    int n, k;
    cout<<"Podaj dwie liczby naturalne: ";
    cin >> n >> k;

    cout << newton(n,k);

}

long long silnia(int a)
{
    long long s = 1;
    for(int i = 1; i <= a; i++)
        s = s * i;

    return s;
}

long long newton(int n, int k)
{
    return silnia(n) / (silnia(k) * silnia(n-k));
}
