﻿This directory will contain the log files for OpenVPN
sessions which are being run as a service.

Logs for connections started by the GUI are kept in
%USERPROFILE%\OpenVPN\log.
