#include<iostream>
using namespace std;

int main()
{
    int n, m;
    cout<<"Podaj liczbe naturalna: ";
    cin >> n;
    int liczba_wierszy, liczba_gwiazdek;
    liczba_wierszy = n;
    liczba_gwiazdek = 1;

    int i = 1, j = 1;
    while(i <= liczba_wierszy)
    {
        while(j <= liczba_gwiazdek)
        {
            cout<<"*";
            j++;
        }
        liczba_gwiazdek++;
        j = 1;
        i++;
        cout << endl;
    }
}
