/*
To jest program obliczajacy sume liczb
*/

#include<iostream>
using namespace std;

int main()
{
    int n, ilosc_liczb;
    double liczba, suma;
    char c;
    bool czy_dalej;

    do
    {
        suma = 0.0;
        ilosc_liczb = 0;
        czy_dalej = true;

        while(czy_dalej == true)
        {
            cout << "Podaj liczbe rzeczywista: ";
            cin >> liczba;
            if (liczba == 0)
                czy_dalej = false;
            else
            {
                suma = suma + liczba;
                ilosc_liczb++;
            }
        }

        cout << "Srednia tych liczb wynosi: " << suma / ilosc_liczb << endl;
        cout << "Czy chcesz powtorzyc (t/n): ";
        cin >> c;

    }  while(c == 't' || c == 'T');

}
