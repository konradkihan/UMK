/*
To jest program obliczajacy sume liczb
*/

#include<iostream>
using namespace std;

int main()
{
    int n;
    double liczba, suma;
    char c;

    do
    {
        suma = 0.0;

        cout << "Podaj ilosc liczb, ktore chcesz wprowadzic: ";
        cin >> n;

        for(int i = 1; i <= n; i++)
        {
            cout << "Podaj "<< i <<" liczbe rzeczywista: ";
            cin >> liczba;
            suma = suma + liczba;
            //suma += liczba;
        }

        cout << "Srednia tych liczb wynosi: " << suma / n << endl;
        cout << "Czy chcesz powtorzyc (t/n): ";
        cin >> c;

    }  while(c == 't' || c == 'T');

}
