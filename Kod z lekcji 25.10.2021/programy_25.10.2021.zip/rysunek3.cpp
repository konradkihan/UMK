#include<iostream>
using namespace std;

int main()
{
    int n;
    cout<<"Podaj liczbe naturalna: ";
    cin >> n;

    for(int nr_wiersza = 1; nr_wiersza <= n; nr_wiersza++)
    {
        for(int j = 1; j <= nr_wiersza; j++)
        {
            cout << "*";
        }
        cout << endl;
    }
}
