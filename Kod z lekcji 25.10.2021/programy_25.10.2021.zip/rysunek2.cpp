#include<iostream>
using namespace std;

int main()
{
    int n, m;
    cout<<"Podaj dwie liczby naturalne: ";
    cin >> m >> n;
    int liczba_wierszy, liczba_gwiazdek;
    liczba_wierszy = n;
    liczba_gwiazdek = m;

    int i = 1, j = 1;
    while(i <= liczba_wierszy)
    {
        while(j <= liczba_gwiazdek)
        {
            cout<<"*";
            j++;
        }
        j = 1;
        i++;
        cout << endl;
    }
}
