#include<iostream>
using namespace std;

int main()
{
    int n = 5, m = 3;

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            cout << i << "," << j << "  ";
        }
        cout << endl;
    }
}
