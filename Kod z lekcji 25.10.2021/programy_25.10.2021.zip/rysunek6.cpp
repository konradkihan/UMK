#include<iostream>
using namespace std;

int main()
{
    int n, m;
    cout<<"Podaj liczbe naturalna: ";
    cin >> n;
    int liczba_wierszy, liczba_gwiazdek, liczba_spacji;
    liczba_wierszy = n;
    liczba_gwiazdek = 1;
    liczba_spacji = liczba_wierszy - 1;

    int i = 1, j = 1, k = 1;
    while(i <= liczba_wierszy)
    {
        while(k <= liczba_spacji)
        {
            cout<<" ";
            k++;
        }

        while(j <= liczba_gwiazdek)
        {
            cout<<"*";
            j++;
        }
        liczba_gwiazdek++;
        liczba_spacji--;
        j = 1; k = 1;
        i++;
        cout << endl;
    }
}
