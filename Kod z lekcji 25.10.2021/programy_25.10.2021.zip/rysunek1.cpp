#include<iostream>
using namespace std;

int main()
{
    int n, m;
    cout<<"Podaj dwie liczby naturalne: ";
    cin >> m >> n;

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= m; j++)
        {
            cout << "*";
        }
        cout << endl;
    }
}
